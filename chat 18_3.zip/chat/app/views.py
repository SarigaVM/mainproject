
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as auth_login,logout
from django.contrib import messages
from .models import *
from django.contrib.auth.decorators import login_required
import datetime



# Create your views here.

def home(request):
    return render(request,'home.html')


from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.models import User
from .models import Register  

def register(request):
    if request.method == "POST":
        full_name = request.POST['full_name']
        email = request.POST['email']
        phone = request.POST['phone']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']

      
        if password != confirm_password:
            messages.error(request, "⚠️ Passwords do not match!")
            return redirect('register')

        if User.objects.filter(username=email).exists():
            messages.error(request, "⚠️ Email is already registered!")
            return redirect('register')

        user = User.objects.create_user(username=email, email=email, password=password, first_name=full_name)
        user.save()

      
        Register.objects.create(user=user, phone=phone)

        messages.success(request, "✅ Registration successful! Please login.")
        return redirect(log)  

    return render(request, 'register.html')





def log(request):
    if request.method == "POST":
        email = request.POST['email']
        password = request.POST['password']
        
        try:
            user_obj = User.objects.get(username=email)
        except User.DoesNotExist:
            messages.error(request, "Email is incorrect!")
            return render(request, 'login.html')

        
        user = authenticate(request, username=email, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect(analyze_brain_ct) 
        else:
            messages.error(request, "Password is incorrect!")

    return render(request, 'login.html')





from PIL import Image
import google.generativeai as genai
import io

from django.http import JsonResponse




# Configure Gemini AI
genai.configure(api_key="AIzaSyAglCMAOG3qxK9Km5uJQ0NFtqhCA2HnXtk")



# from django.http import JsonResponse
# from django.core.files.storage import default_storage
# from django.core.files.base import ContentFile
# from django.shortcuts import render
# from django.utils.timezone import now
# from PIL import Image
# import os
# from .models import Register
     
   
#@login_required(login_url="login")
# def analyze_brain_ct(request):
#     if request.method == "POST":
#         user_input = request.POST.get("user-input", "").strip()
#         response_text = ""
#         image_url = None  # Default: No image uploaded
#         user_image_path = None  # Path to save in DB
#         user = request.user  # Get logged-in user]
       
#       # phone=phone
        
#        # If an image is uploaded, save it temporarily and process it
#         if request.FILES.get("file"):
#             file = request.FILES["file"]
#             img = Image.open(file)

#             # Save image to media folder
#             file_name = default_storage.save(f"uploads/{file.name}", ContentFile(file.read()))
#             image_url = f"/media/{file_name}"  # Construct image URL for frontend display
#             user_image_path = f"uploads/{file.name}"  # Save relative path in DB
        
        
    
#             # AI Prompt for Image Processing
#             prompt = f'''
#             Your role is to analyze the uploaded medical image and respond accordingly.
#             If the image contains a disease, provide:
#             - A brief description of the disease.
#             - Recommended medications.
#             - Likely causes.

#             If no disease is detected, respond:
#             "No disease observed from the given image."

#             User Query: {user_input}
#             '''

#             try:
#                 model = genai.GenerativeModel("gemini-1.5-flash")
#                 response = model.generate_content([prompt, img])
#                 response_text = response.text if response else "Error: No response generated."
#             except Exception as e:
#                 response_text = f"Error processing the request: {str(e)}"

#         # If only text input is given, process it separately
#         elif user_input:
#             greetings = ["hai", "hello", "hey", "good morning", "good afternoon", "good evening"]
#             if any(user_input.lower().startswith(greet) for greet in greetings):
#                 response_text = "Hello! How can I assist you with medical-related queries today?"
#             else:
#                 # AI Prompt for Medical Queries
#                 prompt = f'''
#                 Your role is to respond to medical-related user queries. 
#                 - Provide detailed medical information.
#                 - For medical law-related queries, respond properly.
#                 - If the query is **not medical-related**, reply: "I can assist you only with medical queries."

#                 User Input: {user_input}
#                 '''

#                 try:
#                     model = genai.GenerativeModel("gemini-1.5-flash")
#                     response = model.generate_content(prompt)
#                     response_text = response.text if response else "Error: No response generated."
#                 except Exception as e:
#                     response_text = f"Error processing the request: {str(e)}"

#         # Save to Register model
       
#         current_date=datetime.datetime.now()
#         register_entry = Register.objects.create(
#             user=user,
#             #phone=phone,
#             user_inp=user_input,
#             bot_res=response_text,
#             user_image=user_image_path,  # Save image path
#             curr_date=current_date
#         )

#         return JsonResponse({
#             "user_input": user_input,
#             "response_text": response_text,
#             "image_url": image_url  # If an image was uploaded, send the URL
#         })

#     return render(request, "chat.html")
################################################################################

from django.http import JsonResponse
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from django.shortcuts import render
from django.utils.timezone import now
from PIL import Image
import os
from .models import Register
import datetime  # Ensure datetime is imported


@login_required(login_url="login")
def analyze_brain_ct(request):
    if request.method == "POST":
        user_input = request.POST.get("user-input", "").strip()
        response_text = ""
        image_url = None  # Default: No image uploaded
        user_image_path = None  # Path to save in DB
        user = request.user  # Get logged-in user]
       
        # If an image is uploaded, save it and process it
        if request.FILES.get("file"):
            file = request.FILES["file"]
            
            # Debugging: Print file name and type
            print(f"Uploading file: {file.name}, Content Type: {file.content_type}")

            # Save image correctly
            file_name = default_storage.save(f"uploads/{file.name}", ContentFile(file.read()))
            user_image_path = f"uploads/{file.name}"
            file_path = os.path.join(default_storage.location, user_image_path)

            # Debugging: Check saved file path
            print(f"Saved at: {file_path}")
            print(f"File exists? {os.path.exists(file_path)}")

            # Open the saved image before passing it to the model
            try:
                img = Image.open(file_path)
            except Exception as e:
                response_text = f"Error opening the image: {str(e)}"
                img = None  # Set img to None to avoid further issues
            
            if img:
                # AI Prompt for Image Processing
                prompt = f'''
                Your role is to analyze the uploaded medical image and respond accordingly.
                If the image contains a disease, provide:
                - What the image uploaded is
                - A brief description of the disease.
                - Recommended medications.
                - Likely causes 
                - Next step precautions .
                -Which doctor should be visited.

                If no disease is detected, respond:
                What the image uploaded is and along with that show the message
                "No disease observed from the given image."

                User Query: {user_input}
                '''

                try:
                    model = genai.GenerativeModel("gemini-1.5-flash")
                    response = model.generate_content([prompt, img])
                    response_text = response.text if response else "Error: No response generated."
                except Exception as e:
                    response_text = f"Error processing the request: {str(e)}"

        # If only text input is given, process it separately
        elif user_input:
            greetings = ["hai", "hello", "hey", "good morning", "good afternoon", "good evening","hi","helo"]
            if any(user_input.lower().startswith(greet) for greet in greetings):
                response_text = "Hello! How can I assist you with medical-related queries today?"
            else:
                # AI Prompt for Medical Queries
                prompt = f'''
                Your role is to respond to medical-related user queries. 
                - Provide detailed medical information.
                - For medical law-related queries, respond properly.
                - If the query is **not medical-related**, reply: "I can assist you only with medical queries."

                User Input: {user_input}
                '''

                try:
                    model = genai.GenerativeModel("gemini-1.5-flash")
                    response = model.generate_content(prompt)
                    response_text = response.text if response else "Error: No response generated."
                except Exception as e:
                    response_text = f"Error processing the request: {str(e)}"

        # Save to Register model
        current_date = datetime.datetime.now()
        register_entry = Register.objects.create(
            user=user,
            user_inp=user_input,
            bot_res=response_text,
            user_image=user_image_path,  # Save image path
            curr_date=current_date
        )

        return JsonResponse({
            "user_input": user_input,
            "response_text": response_text,
            "image_url": f"/media/{user_image_path}" if user_image_path else None  # Ensure correct media path
        })

    return render(request, "chat.html")


###########################################################################################################


## shows full chat without filtering date

# def history(request):
#     user_chats = Register.objects.filter(user=request.user).order_by('curr_date')  # Fetch user-specific chat data

#     return render(request, 'history.html', {'user_chats': user_chats})

#========================================================================================================

## Chat with filtering date
#====================================================================================================

# def history(request):
#     user_chats = Register.objects.filter(user=request.user).order_by('-curr_date')

#     # Extract unique dates from chat history (formatted as YYYY-MM-DD)
#     unique_dates = user_chats.values_list('curr_date', flat=True).distinct()

#     # Get selected date from request
#     selected_date = request.GET.get('date')

#     # Filter chats by selected date if provided
#     if selected_date:
#         user_chats = user_chats.filter(curr_date=selected_date)

#     return render(request, 'history.html', {
#         'unique_dates': unique_dates,
#         'user_chats': user_chats,
#         'selected_date': selected_date
#     })


#====================================================================

## updated load recent chat on history


# from django.shortcuts import render
# from django.utils.timezone import now, timedelta
# from .models import Register  # Assuming Register stores the chats

# def history(request):
#     user_chats = Register.objects.filter(user=request.user).order_by('-curr_date')  # Get latest first
#     unique_dates = user_chats.values_list('curr_date', flat=True).distinct()  # Get unique chat dates

#     # Get the selected date from request, or default to the most recent date
#     selected_date = request.GET.get('date')

#     if not selected_date and unique_dates:  
#         # If no date is selected, use today's date or the most recent available
#         today = now().date()
#         if today in unique_dates:
#             selected_date = today
#         else:
#             selected_date = unique_dates[0]  # Use the latest available chat date

#     # Convert selected_date to string for template comparison
#     selected_date_str = str(selected_date)

#     # Filter chats based on the selected date
#     filtered_chats = user_chats.filter(curr_date=selected_date)

#     return render(request, 'history.html', {
#         'user_chats': filtered_chats,
#         'unique_dates': unique_dates,
#         'selected_date': selected_date_str
#     })



from django.shortcuts import render
from django.utils.timezone import now
from .models import Register



@login_required(login_url="login")
def history(request):
    user_chats = Register.objects.filter(user=request.user).order_by('-curr_date')  # Get latest chats first
    
    # Get unique chat dates where at least one entry has either user input or bot response
    unique_dates = set(
        Register.objects.filter(user=request.user)
        .exclude(user_inp__isnull=True, bot_res__isnull=True)
        .values_list('curr_date', flat=True)
        .distinct()
    )

    # Get selected date from request or use the latest available date
    selected_date = request.GET.get('date')

    if not selected_date and unique_dates:
        today = now().date()
        selected_date = today if today in unique_dates else max(unique_dates)

    # Convert selected_date to string for template comparison
    selected_date_str = str(selected_date)

    # Filter chats based on the selected date
    filtered_chats = Register.objects.filter(user=request.user, curr_date=selected_date)

    return render(request, 'history.html', {
        'user_chats': filtered_chats,
        'unique_dates': sorted(unique_dates, reverse=True),
        'selected_date': selected_date_str
    })




#====================================================================


@login_required(login_url="login")
def logout_chat(request):
    logout(request)
    return redirect(home)


def hai(request):
    return HttpResponse("Hello")





