
from django.urls import path
from .import views

urlpatterns = [
   path('',views.home),
   path('reg', views.register, name='register'),
   path('log', views.log, name='login'),
   path('hai',views.hai),
   path('logout_chat',views.logout_chat),
  path("response", views.analyze_brain_ct,name='analyze_brain_ct'),
  path('history', views.history, name='history'),
 
  
]

